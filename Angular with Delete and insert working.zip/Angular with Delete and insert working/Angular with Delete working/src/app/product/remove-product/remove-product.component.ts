import { Component, OnInit } from '@angular/core';
import { error } from 'protractor';
import { Product } from 'src/app/products/product';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-remove-product',
  templateUrl: './remove-product.component.html',
  styleUrls: ['./remove-product.component.css']
})
export class RemoveProductComponent implements OnInit {
  pageTitle:string='Product Detail';
  errorMessage:string;
  product:Product;
  
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }

  ngOnInit() {
    const id=this.route.snapshot.paramMap.get('id');
    const productId= +id;
    this.productService.removeProductDetails(productId).subscribe(
      product=>{
      this.product=null;
    },
    errorMessage=>{
      this.errorMessage=errorMessage;
    })    
  }
public navigateBack():void{
  this.router.navigate(['/remove'])
}
}
