import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/products/product';

@Component({
  selector: 'app-accept-product',
  templateUrl: './accept-product.component.html',
  styleUrls: ['./accept-product.component.css']
})
export class AcceptProductComponent implements OnInit {

  _productId:number;
  _productName:string;
  _code:string;
  _releaseDate:string;
  _price:number;
  _description: string;
  _rating: number;

  error:string;
  product:Product={ productId:0,
    productName:'',
    productCode:'',
    releaseDate:'',
    price:0,
    description: '',
    starRating: 0};

  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }

    get productId():number{
    return this._productId;
  }
  set productId(value:number){
    this._productId = value;
  }
  get productName():string{
    return this._productName;
  }
  set productName(value){
    this._productName = value;
  }
  get code():string{
    return this._code;
  }
  set code(value:string){
    this._code = value;
  }
  get releaseDate():string{
    return this._releaseDate;
  }
  set releaseDate(value:string){
    this._releaseDate = value;
  }
  get price():number{
    return this._price;
  }
  set price(value:number){
    this._price = value;
  }
  get description():string{
    return this._description;
  }
  set description(value:string){
    this._description = value;
  }
  get rating():number{
    return this._rating;
  }
  set rating(value:number){
    this._rating = value;
  } 
    ngOnInit() {
   /*  this.productService.getAllProductsDetails().subscribe(tempProducts => {
      this.products = tempProducts;
      this.productsList=this.products;
    }, error=>{
      this.error=error;
    }) */
    
  }

  public getBack():void{
    /* this.product.productId = 99;
    this.product.productName = "he;;p";
    this.product.productCode = this._code;
    this.product.price = this._price;
    this.product.description = this._description;
    this.product.starRating = this._rating;
    this.product.releaseDate = this._releaseDate;  */
    this.productService.acceptProductDetails(this.product).subscribe(product1 => {
      this.product = product1;
    },
    errorMessage=>{
      this.error=errorMessage;
    });
    this.router.navigate(['/products'])
  }

}
